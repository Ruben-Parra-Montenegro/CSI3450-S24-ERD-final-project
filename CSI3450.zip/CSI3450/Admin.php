<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: auto;
            max-width: 90%;
            text-align: center;
            overflow-x: auto;
        }
        h1, h2 {
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Portal</h1>
        <h2>Data from Database</h2>
        <form method="POST">
            <label for="database">Select Database:</label>
            <select name="database" id="database" onchange="this.form.submit()">
                <option value="finalproject" <?php if (isset($_POST['database']) && $_POST['database'] == 'finalproject') echo 'selected'; ?>>finalproject</option>
                <!-- Add more options for other databases if needed -->
            </select>
            
            <label for="table">Select Table:</label>
            <select name="table" id="table" onchange="this.form.submit()">
                <?php
                    if (isset($_POST['database'])) {
                        $database = $_POST['database'];
                        $conn = new mysqli('localhost', 'Admin1', 'Admin1', $database);
                        
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }
                        
                        $result = $conn->query("SHOW TABLES");
                        
                        while ($row = $result->fetch_array()) {
                            $selected = (isset($_POST['table']) && $_POST['table'] == $row[0]) ? 'selected' : '';
                            echo "<option value='" . $row[0] . "' $selected>" . $row[0] . "</option>";
                        }
                        
                        $conn->close();
                    }
                ?>
            </select>
            
            <input type="submit" name="refresh" value="Refresh Data">
        </form>
        
        <?php
        if (isset($_POST['table'])) {
            $table = $_POST['table'];
            $database = $_POST['database'];
            $conn = new mysqli('localhost', 'Admin1', 'Admin1', $database);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch the primary key column name
            $primaryKeyResult = $conn->query("SHOW KEYS FROM $table WHERE Key_name = 'PRIMARY'");
            $primaryKeyColumn = $primaryKeyResult->fetch_assoc()['Column_name'];

            $result = $conn->query("SELECT * FROM $table");

            if ($result->num_rows > 0) {
                echo "<table border='1'><tr>";
                // Print table headers
                while ($field = $result->fetch_field()) {
                    echo "<th>" . $field->name . "</th>";
                }
                echo "<th>Action</th>"; // Add a column for the delete action
                echo "</tr>";

                // Print table rows
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    foreach ($row as $value) {
                        echo "<td>" . $value . "</td>";
                    }
                    // Add a delete button for each row
                    echo "<td>
                            <form method='POST' action='delete_record.php' style='display:inline;'>
                                <input type='hidden' name='database' value='$database'>
                                <input type='hidden' name='table' value='$table'>
                                <input type='hidden' name='primary_key' value='" . $row[$primaryKeyColumn] . "'>
                                <input type='submit' value='Delete'>
                            </form>
                          </td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }

            $conn->close();
        }
        ?>

        <h2>Add New Record</h2>
        <form method="POST" action="add_record.php">
            <?php
            if (isset($_POST['table'])) {
                $table = $_POST['table'];
                $database = $_POST['database'];
                $conn = new mysqli('localhost', 'Admin1', 'Admin1', $database);
                
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
                $result = $conn->query("DESCRIBE $table");
                
                while ($row = $result->fetch_assoc()) {
                    $field = $row['Field'];
                    echo "<label for='$field'>$field:</label>";
                    echo "<input type='text' id='$field' name='$field'><br><br>";
                }
                
                $conn->close();
            }
            ?>
            <input type="hidden" name="database" value="<?php echo isset($database) ? $database : ''; ?>">
            <input type="hidden" name="table" value="<?php echo isset($table) ? $table : ''; ?>">
            <input type="submit" value="Add">
            <input type="reset" value="Clear Form">
        </form>
        <a href="LoginPage.html">Back to Home Page</a>
    </div>
</body>
</html>