<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: auto;
            max-width: 90%;
            text-align: center;
            overflow-x: auto;
        }
        h1, h2 {
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Portal</h1>
        <h2>Job Openings</h2>
        <form method="POST">
            <input type="hidden" name="database" value="finalproject">
            <input type="hidden" name="table" value="opening">
            <input type="submit" name="refresh" value="Refresh Data">
        </form>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $database = 'finalproject';
            $table = 'opening';
            $conn = new mysqli('localhost', 'User1', 'User1', $database);
            
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            $result = $conn->query("SELECT * FROM $table");
            
            if ($result->num_rows > 0) {
                echo "<table><tr>";
                // Fetch table headers
                while ($field = $result->fetch_field()) {
                    echo "<th>" . $field->name . "</th>";
                }
                echo "<th>Description</th>"; // Add a header for the description button
                echo "</tr>";
                
                // Fetch table rows
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    foreach ($row as $data) {
                        echo "<td>" . $data . "</td>";
                    }
                    // Add a button linking to the description page
                    echo "<td><a href='description.php?id=" . $row['OpeningID'] . "'>View Description</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            
            $conn->close();
        }
        ?>
        <a href="LoginPage.html">Back to Home Page</a>
    </div>
</body>
</html>