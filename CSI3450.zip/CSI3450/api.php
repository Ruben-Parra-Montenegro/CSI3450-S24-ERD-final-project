<?php
$servername = "localhost";
$username = "Admin1";
$password = "Admin1";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['action'])) {
        $action = $_GET['action'];
        if ($action === 'getDatabases') {
            $sql = "SHOW DATABASES";
            $result = $conn->query($sql);
            $databases = [];
            while ($row = $result->fetch_assoc()) {
                $databases[] = $row['Database'];
            }
            echo json_encode($databases);
        } elseif ($action === 'getTables' && isset($_GET['database'])) {
            $database = $_GET['database'];
            $conn->select_db($database);
            $sql = "SHOW TABLES";
            $result = $conn->query($sql);
            $tables = [];
            while ($row = $result->fetch_assoc()) {
                $tables[] = $row["Tables_in_$database"];
            }
            echo json_encode($tables);
        } elseif ($action === 'getData' && isset($_GET['table'])) {
            $table = $_GET['table'];
            $sql = "SELECT * FROM $table";
            $result = $conn->query($sql);
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode($data);
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $table = $input['table'];
    $name = $input['name'];
    $sql = "INSERT INTO $table (name) VALUES ('$name')";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Record added"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $table = $_GET['table'];
    $id = $_GET['id'];
    $sql = "DELETE FROM $table WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Record deleted"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
}

$conn->close();
?>