<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = $_POST['database'];
    $table = $_POST['table'];
    $primary_key = $_POST['primary_key']; // Adjust 'primary_key' to your primary key column
    $conn = new mysqli('localhost', 'Admin1', 'Admin1', $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the primary key column name dynamically
    $result = $conn->query("SHOW KEYS FROM $table WHERE Key_name = 'PRIMARY'");
    $primaryKeyColumn = $result->fetch_assoc()['Column_name'];

    // Prepare the delete statement using the correct primary key column
    $stmt = $conn->prepare("DELETE FROM $table WHERE $primaryKeyColumn = ?");
    $stmt->bind_param('i', $primary_key);
    if ($stmt->execute()) {
        echo "Record deleted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
    // Redirect back to the main page
    header("Location: Admin.php");
    exit();
}
?>