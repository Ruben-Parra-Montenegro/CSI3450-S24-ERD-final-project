<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = $_POST['database'];
    $table = $_POST['table'];
    $conn = new mysqli('localhost', 'Admin1', 'Admin1', $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch table columns
    $result = $conn->query("DESCRIBE $table");
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }

    // Prepare the SQL statement
    $fields = implode(", ", $columns);
    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $stmt = $conn->prepare("INSERT INTO $table ($fields) VALUES ($placeholders)");

    // Bind parameters
    $types = str_repeat('s', count($columns)); // Assuming all columns are strings for simplicity
    $values = [];
    foreach ($columns as $column) {
        $values[] = $_POST[$column] ?? null; // Use null if the field is not set
    }
    $stmt->bind_param($types, ...$values);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>