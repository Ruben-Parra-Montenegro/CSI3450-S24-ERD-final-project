<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = $_POST['database'] ?? 'finalproject';
    $table = $_POST['table'] ?? 'candidate';
    $openingId = $_POST['OpeningID'] ?? null;
    $Name = $_POST['Name'] ?? null;
    $candidateEmail = $_POST['CandidateEmail'] ?? null;
    $JobRecord = $_POST['JobRecord'] ?? null;
    $candidateAddress = $_POST['CandidateAddress'] ?? null;
    $candidatePhoneNumber = $_POST['CandidatePhoneNumber'] ?? null;
    $JobDescription = $_POST['JobDescription'] ?? null;
    $startDate = $_POST['StartDate'] ?? null;
    $endDate = $_POST['EndDate'] ?? null;

    $conn = new mysqli('localhost', 'User1', 'User1', $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

     // Insert candidate information
     $stmt = $conn->prepare("INSERT INTO candidate (Name, CandidateEmail, CandidatePhoneNumber, CandidateAddress) VALUES (?, ?, ?, ?)");
     if ($stmt === false) {
         die("Prepare failed: " . $conn->error);
     }
     $stmt->bind_param("ssss", $Name, $candidateEmail, $candidatePhoneNumber, $candidateAddress);
     $stmt->execute();
     $candidateId = $stmt->insert_id; // Get the auto-generated CandidateID
     $stmt->close();

    // Insert job history information
    $stmt = $conn->prepare("INSERT INTO job_history (CandidateID, JobRecord, JobDescription, StartDate, EndDate) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("issss", $candidateId, $JobRecord, $JobDescription, $startDate, $endDate);
    $stmt->execute();
    $stmt->close();

  

    echo "Application submitted successfully!";
} else {
    echo "Invalid request method.";
}
?>