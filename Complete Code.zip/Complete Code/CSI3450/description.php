<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opening Description</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: auto;
            max-width: 90%;
            text-align: center;
            overflow-x: auto;
        }
        h1, h2 {
            color: #333;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .back-button {
            margin-top: 20px;
        }
        .back-button a {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 16px;
        }
        .back-button a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="container">
    <?php
    
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $database = 'finalproject';
        $conn = new mysqli('localhost', 'User1', 'User1', $database);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $stmt = $conn->prepare("
            SELECT o.*, c.CompanyName 
            FROM opening o
            JOIN company c ON o.CompanyID = c.CompanyID
            WHERE o.OpeningID = ?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<h1>Opening Description</h1>";
            echo "<table>";
            foreach ($row as $field => $value) {
                echo "<tr><th>" . htmlspecialchars($field) . "</th><td>" . htmlspecialchars($value) . "</td></tr>";
            }
            echo "</table>";
         
        } else {
            echo "<p>No description found for this opening.</p>";
        }
        $stmt->close();
        $conn->close();
    } else {
        echo "<p>No ID provided.</p>";
    }
    ?>

    <div class="back-button">
        <a href="Application.php?opening_id=<?php echo htmlspecialchars($id); ?>">Apply</a>
    </div>
    <div class="back-button">
        <a href="User.php">Back to Openings</a>
    </div>
</div>
</body>
</html>