<?php
// Connect to the database
$database = 'finalproject';
$conn = new mysqli('localhost', 'User1', 'User1', $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch the OpeningID from the URL parameter
$openingId = $_GET['opening_id'] ?? null;
if ($openingId) {
    $stmt = $conn->prepare("SELECT * FROM opening WHERE OpeningID = ?");
    $stmt->bind_param("i", $openingId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $opening = $result->fetch_assoc();
    } else {
        echo "No opening found with ID: " . htmlspecialchars($openingId);
        exit();
    }
    $stmt->close();
} else {
    echo "No opening ID provided.";
    exit();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: auto;
            max-width: 90%;
            text-align: center;
            overflow-x: auto;
        }
        h1, h2 {
            color: #333;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .back-button {
            margin-top: 20px;
        }
        .back-button a {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 16px;
        }
        .back-button a:hover {
            background-color: #45a049;
        }
        .submit-button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    margin-top: 20px;
}
.submit-button:hover {
    background-color: #45a049;
}
    </style>
</head>
<body>
<div class="container">
    <h1>Apply for Opening ID: <?php echo htmlspecialchars($opening['OpeningID']); ?></h1>
    <form method="POST" action="add_user_record.php">
        <input type="hidden" name="database" value="finalproject">
        <input type="hidden" name="table" value="candidate">
        <input type="hidden" name="OpeningID" value="<?php echo htmlspecialchars($opening['OpeningID']); ?>">
        <h2>Candidate Information</h2>
        <label for="Name">Name:</label>
        <input type="text" id="Name" name="Name" required><br><br>
        <label for="CandidateEmail">Email:</label>
        <input type="email" id="CandidateEmail" name="CandidateEmail" required><br><br>
        <label for="CandidatePhoneNumber">Phone Number:</label>
        <input type="text" id="CandidatePhoneNumber" name="CandidatePhoneNumber" required><br><br>
        <label for="CandidateAddress">Address:</label>
        <input type="text" id="CandidateAddress" name="CandidateAddress" required><br><br>
        <h2>Job History</h2>
        <label for="PreviousJobTitle">Previous Job Title:</label>
        <input type="text" id="JobRecord" name="JobRecord" required><br><br>
        <label for="JobDescription">Job Description:</label>
        <input type="text" id="JobDescription" name="JobDescription" required><br><br>
        <label for="StartDate">Start Date:</label>
        <input type="date" id="StartDate" name="StartDate" required><br><br>
        <label for="EndDate">End Date:</label>
        <input type="date" id="EndDate" name="EndDate" required><br><br>
        <div class="back-button">
            <button type="submit" class="submit-button">Submit Application</button>
        </div>
    </form>
    <div class="back-button">
        <a href="User.php" class="button">Back to Openings</a>
    </div>
</div>
</body>
</html>