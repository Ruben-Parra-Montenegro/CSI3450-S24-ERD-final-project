-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2024 at 05:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `CandidateID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `CandidateAddress` varchar(255) DEFAULT NULL,
  `CandidateEmail` varchar(255) DEFAULT NULL,
  `CandidatePhoneNumber` varchar(20) DEFAULT NULL,
  `openingID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`CandidateID`, `Name`, `CandidateAddress`, `CandidateEmail`, `CandidatePhoneNumber`, `openingID`) VALUES
(164, 'Jon', '3333333333', 'Jon@gmail.com', '3333333333', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompanyID` int(11) NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `CompanyAddress` varchar(255) DEFAULT NULL,
  `CompanyEmail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompanyID`, `CompanyName`, `CompanyAddress`, `CompanyEmail`) VALUES
(0, 'Jon Company', 'Jon street', 'Jon@jon.com'),
(1, 'cool Company', 'cool street', 'cool@cool.com'),
(2, 'Company', 'Company street', 'Company@Company.com'),
(3, 'Car Company', 'Car street', 'Car@Car.com');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `CourseID` int(11) NOT NULL,
  `CourseName` varchar(255) DEFAULT NULL,
  `QualificationCode` int(11) DEFAULT NULL,
  `CoursePrerequisites` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_history`
--

CREATE TABLE `job_history` (
  `JobHistoryID` int(11) NOT NULL,
  `CandidateID` int(11) DEFAULT NULL,
  `JobRecord` varchar(255) DEFAULT NULL,
  `JobDescription` varchar(255) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_history`
--

INSERT INTO `job_history` (`JobHistoryID`, `CandidateID`, `JobRecord`, `JobDescription`, `StartDate`, `EndDate`) VALUES
(23, 164, 'hhhh', 'jon', '2024-08-18', '2024-08-29');

-- --------------------------------------------------------

--
-- Table structure for table `opening`
--

CREATE TABLE `opening` (
  `OpeningID` int(11) NOT NULL,
  `CompanyID` int(11) DEFAULT NULL,
  `QualificationCode` int(11) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `HourlyPay` decimal(10,2) DEFAULT NULL,
  `JobTitle` varchar(100) DEFAULT NULL,
  `JobDescription` varchar(100) DEFAULT NULL,
  `DatePosted` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `opening`
--

INSERT INTO `opening` (`OpeningID`, `CompanyID`, `QualificationCode`, `StartDate`, `EndDate`, `HourlyPay`, `JobTitle`, `JobDescription`, `DatePosted`) VALUES
(1, 1, 0, '2024-08-18', '2024-12-18', 25.00, 'Cool Person', 'Just be cool', '2024-08-18'),
(2, 3, 0, '2024-08-18', '2033-12-18', 30.00, 'Car Maker', 'You make Cars', '2024-08-18');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `PlacementID` int(11) NOT NULL,
  `OpeningID` int(11) DEFAULT NULL,
  `CandidateID` int(11) DEFAULT NULL,
  `TotalHoursWorked` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `QualificationCode` int(11) NOT NULL,
  `QualificationDescription` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`QualificationCode`, `QualificationDescription`) VALUES
(0, 'Hard worker');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `SessionID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `SessionDate` date DEFAULT NULL,
  `SessionFee` decimal(10,2) DEFAULT NULL,
  `MaxCapacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`CandidateID`),
  ADD KEY `fk_openingID` (`openingID`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`CompanyID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`CourseID`),
  ADD KEY `QualificationCode` (`QualificationCode`);

--
-- Indexes for table `job_history`
--
ALTER TABLE `job_history`
  ADD PRIMARY KEY (`JobHistoryID`),
  ADD KEY `CandidateID` (`CandidateID`);

--
-- Indexes for table `opening`
--
ALTER TABLE `opening`
  ADD PRIMARY KEY (`OpeningID`),
  ADD KEY `CompanyID` (`CompanyID`),
  ADD KEY `QualificationCode` (`QualificationCode`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`PlacementID`),
  ADD KEY `OpeningID` (`OpeningID`),
  ADD KEY `CandidateID` (`CandidateID`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`QualificationCode`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`SessionID`),
  ADD KEY `CourseID` (`CourseID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `CandidateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `job_history`
--
ALTER TABLE `job_history`
  MODIFY `JobHistoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidate`
--
ALTER TABLE `candidate`
  ADD CONSTRAINT `fk_openingID` FOREIGN KEY (`openingID`) REFERENCES `opening` (`OpeningID`);

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`QualificationCode`) REFERENCES `qualification` (`QualificationCode`);

--
-- Constraints for table `job_history`
--
ALTER TABLE `job_history`
  ADD CONSTRAINT `job_history_ibfk_1` FOREIGN KEY (`CandidateID`) REFERENCES `candidate` (`CandidateID`);

--
-- Constraints for table `opening`
--
ALTER TABLE `opening`
  ADD CONSTRAINT `opening_ibfk_1` FOREIGN KEY (`CompanyID`) REFERENCES `company` (`CompanyID`),
  ADD CONSTRAINT `opening_ibfk_2` FOREIGN KEY (`QualificationCode`) REFERENCES `qualification` (`QualificationCode`);

--
-- Constraints for table `placement`
--
ALTER TABLE `placement`
  ADD CONSTRAINT `placement_ibfk_1` FOREIGN KEY (`OpeningID`) REFERENCES `opening` (`OpeningID`),
  ADD CONSTRAINT `placement_ibfk_2` FOREIGN KEY (`CandidateID`) REFERENCES `candidate` (`CandidateID`);

--
-- Constraints for table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `session_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
